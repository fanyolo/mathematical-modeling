import pandas as pd
import matplotlib.pyplot as plt

# 加载数据
output_excel = "问题五对比结果.xlsx"
data = pd.read_excel(output_excel)

# 可视化 PSNR 对比 (折线图)
plt.figure(figsize=(10, 6))
plt.plot(data["image file name"], data["PSNR (Original)"], marker='o', label="PSNR (Original)")
plt.plot(data["image file name"], data["PSNR (Comprehensive)"], marker='o', label="PSNR (Comprehensive)")
plt.title("PSNR Comparison: Original vs Comprehensive Enhancement")
plt.xlabel("Image File Name")
plt.ylabel("PSNR")
plt.xticks([])  # 避免过多的x轴标签
plt.legend()
plt.grid()
plt.tight_layout()
plt.show()

# 可视化 UCIQE 对比 (折线图)
plt.figure(figsize=(10, 6))
plt.plot(data["image file name"], data["UCIQE (Original)"], marker='o', label="UCIQE (Original)", color='orange')
plt.plot(data["image file name"], data["UCIQE (Comprehensive)"], marker='o', label="UCIQE (Comprehensive)", color='red')
plt.title("UCIQE Comparison: Original vs Comprehensive Enhancement")
plt.xlabel("Image File Name")
plt.ylabel("UCIQE")
plt.xticks([])  # 避免过多的x轴标签
plt.legend()
plt.grid()
plt.tight_layout()
plt.show()

# 可视化 UIQM 对比 (折线图)
plt.figure(figsize=(10, 6))
plt.plot(data["image file name"], data["UIQM (Original)"], marker='o', label="UIQM (Original)", color='green')
plt.plot(data["image file name"], data["UIQM (Comprehensive)"], marker='o', label="UIQM (Comprehensive)", color='blue')
plt.title("UIQM Comparison: Original vs Comprehensive Enhancement")
plt.xlabel("Image File Name")
plt.ylabel("UIQM")
plt.xticks([])  # 避免过多的x轴标签
plt.legend()
plt.grid()
plt.tight_layout()
plt.show()
